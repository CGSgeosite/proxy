﻿_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/
       GEOsiteProxy 跨域代理服务接口（webAPI）                               
_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/_/

一、如何安装

方案1：使用 IIS 在 Windows 上托管 geositeproxy
  第一步：在服务器上安装 .NET Core Windows Server 托管捆绑包： https://aka.ms/dotnetcore-2-windowshosting
  第二步：创建 IIS 站点：在“IIS 管理器”中，打开“连接”面板中的服务器节点。 右键单击“站点”文件夹。 选择上下文菜单中的“添加网站”
  第三步：提供站点名称（比如：geositeproxy），并将物理路径设置为geositeproxy部署文件夹。 通过“绑定”配置端口等信息，然后“确定”创建网站
  第四步：在服务器节点下，选择“应用程序池”，右键单击站点的应用池，然后从上下文菜单中选择“基本设置”，在“编辑应用程序池”窗口中，将“.NET CLR 版本”设置为“无托管代码”
  提示：如果更新geositeproxy部署文件夹，需暂停站点服务

方案2：采用Docker容器
  在服务器端（支持：Windows、Linux）需安装docker，确保已装载了以下 Docker 映像
  microsoft/aspnetcore-build:2.0
  microsoft/aspnetcore:2.0  
  
  创建镜像：---------------------------------------------------注意末尾有个小数点儿
  docker build -f ./geositeproxy/dockerfile  -t geositeproxy .

  存储镜像：----------------------------------
  docker save -o geositeproxy.tar geositeproxy

  加载镜像：----------------------
  docker load -i geositeproxy.tar

  运行镜像：-------------------------------------------------
  docker run -it --rm --name geositeproxy geositeproxy

  docker容器化是软件开发的一种方法，通过该方法可将应用程序或服务、其依赖项及其配置一起打包为容器映像
  docker容器在整个应用程序生命周期工作流中提供以下优点：隔离性、可移植性、灵活性、可伸缩性和可控性。最重要的优点是可在开发和操作之间提供隔离
  docker容器所需的资源要少得多（例如，不需要一个完整的 OS），所以启动速度快且易于部署，资源使用率较低，部署密度更高

  若使用 Windows 容器，可直接在浏览器中导航到容器的 IP 地址（特别注意，容器IP并非本机http://localhost），可通过以下步骤获取容器 IP 地址：
  第一步：打开命令提示符，比如：
  ---------------------------------------------------------------------------------
  PS D:\> docker ps
  CONTAINER ID IMAGE         COMMAND                   ...   PORTS  NAMES
  df8d3fe9c281 geositeproxy  "dotnet geositeproxy…"   ...   80/tcp vibrant_mclean
  ---------------------------------------------------------------------------------
  第二步：利用geositeproxy镜像对应的NAMES获取ip，比如：
  ---------------------------------------------------------------------------------
  PS D:\> docker exec vibrant_mclean ipconfig
  Windows IP Configuration
  Ethernet adapter Ethernet:
  Connection-specific DNS Suffix  . :
  Link-local IPv6 Address . . . . . : fe80::4c70:711e:8421:24a9%4
  IPv4 Address. . . . . . . . . . . : 172.21.6.251
  Subnet Mask . . . . . . . . . . . : 255.255.240.0
  Default Gateway . . . . . . . . . : 172.21.0.1
  ---------------------------------------------------------------------------------
  第三步：可在浏览器地址栏查看webAPI接口帮助信息，比如：http://172.21.6.251/swagger/

  另外，可使用以下命令在 Windows、Linux 或 macOS 中运行应用程序，形如：
  dotnet geositeproxy.dll

  #删除一个容器
  docker rm 容器ID

  #删除一个镜像
  docker rmi 镜像ID

  #查看所有镜像
  docker images

  #查看正在运行的容器
  docker ps

二、如何访问
	1、help 或者 swagger 指令 
	显示接口使用说明及技术参数

	2、空指令 
	跨域代理服务。从指定的远程地址url（若url中仍附有问号?或和号&amp;，请用%3f代替?，用%26代替&amp;）获取信息，可指定url限定的域名domain、用户名username和密码password，调用结果按xml/json格式返回（若内容无法转换为xml，便按string标签返回；若调用失败，便按error标签返回）
